clear
echo "enter a number: "
read n
r=2
flag=0
cnd=` expr $n \/ 2 `
while [ $r \< $cnd ] 
do
mod=` expr $n % $r `

	if [ $mod = 0 ]
	then
		flag=1
	fi
	r=` expr $r + 1 `
done
if [ $flag = 1 ]
then echo "Not a prime" 
else
	echo "It is prime" 
fi


