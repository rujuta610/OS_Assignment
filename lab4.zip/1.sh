clear
ch=1
while [ $ch = 1 ] 
echo "enter your number"
read n
do
echo `expr $n \* $n`
echo "do you want to contniue? press 1 for yes 0 ottherwise"
read ch
if [ $ch = 0 ]
then exit
fi
done
