echo "enter the string: "
read str
echo "filename: "
read fname
if grep -q $str $fname
then
	echo "string found"
else 
	echo "string not found"
	fi
