clear 
echo "input salary: "
read p
echo HRA is `expr $p \/ 10`
